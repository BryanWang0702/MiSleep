# -*- coding: UTF-8 -*-
"""
@Project: misleep
@File: channel.py
@Author: Xueqiang Wang
@Date: 2024/2/28
@Description:  Some operations based on channels in the signal data
               Include: Rename channel, channel differential

               The data contains signals, channel name, channel sample frequency
"""




