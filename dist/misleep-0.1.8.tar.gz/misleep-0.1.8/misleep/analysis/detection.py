

def SWA_detection(signal, freq_band=[0.5, 4]):
    """Slow wave activity detection
    Detect form trough to peaks with relative amplitude
    """

    


def spindle_detection(signal, freq_band=[10, 15]):
    """Spindle detection"""


def artifact_detection(signal):
    """Artifact detection"""



