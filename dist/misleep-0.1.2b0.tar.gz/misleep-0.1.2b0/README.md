# MiSleep
MiSleep is for EEG/EMG signal processing and visualization

## Get start
```shell
pip install misleep
```